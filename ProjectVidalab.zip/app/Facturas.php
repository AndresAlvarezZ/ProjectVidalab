<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Compras;

class Facturas extends Model
{
    protected $primaryKey = 'idFactura';
    protected $fillable = [
      'idCliente',
      'descuento',
      'total',
      'fecha',
      'condicionDeCompra'
    ];

    public function Compras()
    {
      return $this->hasMany(Compras::class);
    }
}
