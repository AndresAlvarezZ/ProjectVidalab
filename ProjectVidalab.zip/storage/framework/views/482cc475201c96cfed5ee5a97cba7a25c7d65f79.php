
<!-- MODAL LEER MÁS EN ANALISIS-->
<?php $__currentLoopData = $pruebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prueba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e($prueba->codigoDelAnalisis); ?>" tabindex="-1" aria-labelledby="<?php echo e($prueba->codigoDelAnalisis); ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="LeerMasDelAnalisisLabel"><strong>Información del Análisis</strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table>
          <tr>
            <td><strong>Nombre del análisis:</strong></td>
            <td id="mod"><?php echo e($prueba->nombreDelAnalisis); ?></td>
          </tr>
          <tr>
            <td><strong>Costo del anális:</strong></td>
            <td id="mod"><?php echo e($prueba->costoDelAnalisis); ?></td>
          </tr>
          <tr>
            <td><strong>Descripción del análisis:</strong></td>
            <td id="mod"><?php echo e($prueba->descripcionDelAnalisis); ?></td>
          </tr>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<!-- MODAL LEER MÁS EN PAQUETES-->
<?php $__currentLoopData = $paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="<?php echo e($paquete->codigoDelPaquete); ?>" tabindex="-1" aria-labelledby="<?php echo e($paquete->codigoDelPaquete); ?>" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="LeerMasDelPaqueteLabel"><strong>Informacion del paquete</strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table>
          <tr>
            <td><strong>Nombre del paquete:</strong></td>
            <td id="mod"><?php echo e($paquete->nombreDelPaquete); ?></td>
          </tr>
          <tr>
            <td><strong>Costo del paquete:</strong></td>
            <td id="mod"><?php echo e($paquete->costoDelPaquete); ?></td>
          </tr>
          <tr>
            <td><strong>Descripción del paquete:</strong></td>
            <td id="mod"><?php echo e($paquete->descripcionDelPaquete); ?></td>
          </tr>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/pop_up/modal.blade.php ENDPATH**/ ?>