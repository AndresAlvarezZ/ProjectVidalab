<!doctype html>
<html>
  <head>
  </head>
  <body>
    

    <?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Modulo de Afiliación')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="/afiliarme">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="dniDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cédula')); ?></label>

                                <div class="col-md-6">
                                    <input id="dniDelCliente" type="integer" class="form-control <?php $__errorArgs = ['dniDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dniDelCliente" readonly value="<?php echo e(auth()->user()->dniDelUsuario); ?>" required autocomplete="dniDelCliente" autofocus>

                                    <?php $__errorArgs = ['dniDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="nombreDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                                <div class="col-md-6">
                                    <input id="nombreDelCliente" type="text" class="form-control <?php $__errorArgs = ['nombreDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombreDelCliente" value="<?php echo e(old('nombreDelCliente')); ?>" required autocomplete="nombreDelCliente" autofocus>

                                    <?php $__errorArgs = ['nombreDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="primerApellidoDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Primer Apellido')); ?></label>

                                <div class="col-md-6">
                                    <input id="primerApellidoDelCliente" type="text" class="form-control <?php $__errorArgs = ['primerApellidoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="primerApellidoDelCliente" value="<?php echo e(old('primerApellidoDelCliente')); ?>" required autocomplete="primerApellidoDelCliente" autofocus>

                                    <?php $__errorArgs = ['primerApellidoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="segundoApellidoDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Segundo Apellido')); ?></label>

                                <div class="col-md-6">
                                    <input id="segundoApellidoDelCliente" type="text" class="form-control <?php $__errorArgs = ['segundoApellidoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="segundoApellidoDelCliente" value="<?php echo e(old('segundoApellidoDelCliente')); ?>" required autocomplete="segundoApellidoDelCliente" autofocus>

                                    <?php $__errorArgs = ['segundoApellidoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="fechaDeNacimientoDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha de Nacimiento')); ?></label>

                                <div class="col-md-6">
                                    <input id="fechaDeNacimientoDelCliente" type="date" class="form-control <?php $__errorArgs = ['fechaDeNacimientoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fechaDeNacimientoDelCliente" value="<?php echo e(old('fechaDeNacimientoDelCliente')); ?>" required autocomplete="fechaDeNacimientoDelCliente" autofocus>

                                    <?php $__errorArgs = ['fechaDeNacimientoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="edadDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Edad')); ?></label>

                                <div class="col-md-6">
                                    <input id="edadDelCliente" type="integer" class="form-control <?php $__errorArgs = ['edadDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="edadDelCliente" value="<?php echo e(old('edadDelCliente')); ?>" required autocomplete="edadDelCliente" autofocus>

                                    <?php $__errorArgs = ['edadDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="correoDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo')); ?></label>

                                <div class="col-md-6">
                                    <input id="correoDelCliente" type="email" readonly class="form-control <?php $__errorArgs = ['correoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="correoDelCliente" value="<?php echo e(Auth()->User()->email); ?>" required autocomplete="correoDelCliente" autofocus>

                                    <?php $__errorArgs = ['correoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="telefonoDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Teléfono')); ?></label>

                                <div class="col-md-6">
                                    <input id="telefonoDelCliente" type="text" class="form-control <?php $__errorArgs = ['telefonoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefonoDelCliente" value="<?php echo e(old('telefonoDelCliente')); ?>" required autocomplete="telefonoDelCliente" autofocus>

                                    <?php $__errorArgs = ['telefonoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="domicilioDelCliente" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Domicilio')); ?></label>

                                <div class="col-md-6">
                                    <input id="domicilioDelCliente" type="text" class="form-control <?php $__errorArgs = ['domicilioDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="domicilioDelCliente" value="<?php echo e(old('domicilioDelCliente')); ?>" required autocomplete="domicilioDelCliente" autofocus>

                                    <?php $__errorArgs = ['domicilioDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="aceptacionDeTerminos" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Aceptar Términos')); ?></label>

                                <div class="col-md-6">
                                    <input id="aceptacionDeTerminos" type="checkbox" class="form-control <?php $__errorArgs = ['aceptacionDeTerminos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="aceptacionDeTerminos" value="true" required autocomplete="aceptacionDeTerminos" autofocus>
                                    <?php $__errorArgs = ['aceptacionDeTerminos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Afiliarme')); ?>

                                    </button>

                                </div>
                            </div>
                        </form>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
  </body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/clientes/ingresarCliente.blade.php ENDPATH**/ ?>