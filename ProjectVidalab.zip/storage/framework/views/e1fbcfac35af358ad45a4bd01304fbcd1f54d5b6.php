

<?php $__env->startSection('content'); ?>
    
<div class="container"> 
    <div class="card">
        <div class="card-header">
            <h3><b><center>Consultar administradores registrados</center></b></h3>  
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col">
                    <label for="exampleFormControlSelect1">Rol</label>
                    <input type="text" class="form-control" readonly="rol" value="<?php echo e($administrador->rol); ?>"/> <br> 
                </div>
                <div class="col"> 
                    <label for="exampleFormControlSelect1">Estado</label>
                    <input type="text" class="form-control" readonly="estadoDelUsuarioAdministrador" value="<?php echo e($administrador->estadoDelUsuarioAdministrador); ?>"/> <br> 
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label for="exampleFormControlSelect1">Identificación</label>
                    <input type="text" class="form-control" readonly="dniDelUsuarioAdministrador" value="<?php echo e($administrador->dniDelUsuarioAdministrador); ?>"/> <br> 
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Nombre</label>
                    <input type="text" class="form-control" readonly="nombreDelUsuarioAdministrador" value="<?php echo e($administrador->nombreDelUsuarioAdministrador); ?>"/> <br>
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Primer apellido</label>
                    <input type="text" class="form-control" readonly="primerApellidoAdministrador" value="<?php echo e($administrador->primerApellidoAdministrador); ?>"/> <br> 
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Segundo apellido</label>
                    <input type="text" class="form-control" readonly="segundoApellidoAdministrador" value="<?php echo e($administrador->segundoApellidoAdministrador); ?>"/> <br>
                </div>
            </div> 

            <div class="row">
                <div class="col">
                    <label for="exampleFormControlSelect1">Número telefónico</label>
                    <input type="text" class="form-control" readonly="telefonoDelUsuarioAdministrador" value="<?php echo e($administrador->telefonoDelUsuarioAdministrador); ?>"/> <br> 
                </div>
                <div class="col"> 
                    <label for="exampleFormControlSelect1">Correo electrónico</label>
                    <input type="text" class="form-control" readonly="email" value="<?php echo e($administrador->email); ?>"/> <br> 
                </div>
            </div>  

            <div class="row">
                <div class="col">
                    <center><a href="/administradores" class="btn btn-danger">Regresar a la lista</a></center> 
                </div>
                <div class="col">
                    <center><a href="/homeAdmins" class="btn btn-danger">Ir al menú principal</a></center> 
                </div>          
            </div>
        </div> 
    </div>
</div>                    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/administrador/mostrar.blade.php ENDPATH**/ ?>