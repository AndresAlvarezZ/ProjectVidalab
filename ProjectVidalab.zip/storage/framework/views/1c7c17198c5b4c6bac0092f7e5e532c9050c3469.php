

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="card">
        <div class="card-header">
           <h3><b><center>Actualizar estado de sministrador</center></h3></b>
        </div>

        <div class="card-body">

            <form action="/administradores/estado/<?php echo e($administrador->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Identificación</label>
                        <input type="text" class="form-control" readonly="dniDelUsuarioAdministrador" value="<?php echo e($administrador->dniDelUsuarioAdministrador); ?>"/> <br>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Nombre</label>
                        <input type="text" class="form-control" readonly="nombreDelUsuarioAdministrador" value="<?php echo e($administrador->nombreDelUsuarioAdministrador); ?>"/> <br>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Primer apellido</label>
                        <input type="text" class="form-control" readonly="primerApellidoAdministrador" value="<?php echo e($administrador->primerApellidoAdministrador); ?>"/> <br>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Segundo apellido</label>
                        <input type="text" class="form-control" readonly="segundoApellidoAdministrador" value="<?php echo e($administrador->segundoApellidoAdministrador); ?>"/> <br>
                    </div>
                </div>

                <div class="row">

                    <div class="col">
                        <label for="exampleFormControlSelect1">Estado Actual</label>
                        <br>
                        <?php if($administrador->estadoDelUsuarioAdministrador == true): ?>
                            <input type="text" class="alert alert-success" name="estadoDelUsuarioAdministrador" readonly="estadoDelUsuarioAdministrador" value="Activo"/> <br>
                        <?php else: ?>
                            <input type="text" class="alert alert-danger" name="estadoDelUsuarioAdministrador" readonly="estadoDelUsuarioAdministrador" value= "Inactivo"/> <br>
                        <?php endif; ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Motivo</label>
                        <input type="text" class="form-control" readonly="motivoDeEstadoDelUsuarioAdministrador" value="<?php echo e($administrador->motivoDeEstadoDelUsuarioAdministrador); ?>"/>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Estado a asignar</label> <br>
                        <?php if($administrador->estadoDelUsuarioAdministrador == true): ?>

                            <input type="text" class="alert alert-danger" name="estadoDelUsuarioAdministrador" readonly="estadoDelUsuarioAdministrador" value="false"/> <br>
                            <label for="exampleFormControlSelect1">Motivo de inactividad</label>
                        <?php else: ?>
                            <input type="text" class="alert alert-success" name="estadoDelUsuarioAdministrador" readonly="estadoDelUsuarioAdministrador" value= "true"/> <br>
                            <label for="exampleFormControlSelect1">Motivo de actividad</label>
                        <?php endif; ?>
                    </div>
                </div>


                <input type="text" class="form-control" placeholder="Escriba el motivo de cambio de estado" name="motivoDeEstadoDelUsuarioAdministrador" value="<?php echo e(old('motivoDeEstadoDelUsuarioAdministrador')); ?>" />
                <?php $__errorArgs = ['motivoDeEstadoDelUsuarioAdministrador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <p></p>

                <div class="row">
                    <div class="col">
                        <center>
                            <?php if($administrador->estadoDelUsuarioAdministrador == true): ?>
                                <button type="submit" class="btn btn-danger">Desactivar</button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-success">Activar</button>
                            <?php endif; ?>
                        </center>
                    </div>
                    <div class="col">
                        <center><a href="/administradores" class="btn btn-primary">Cancelar y Volver</a></center>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/administrador/editarEstado.blade.php ENDPATH**/ ?>