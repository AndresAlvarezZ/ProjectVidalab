

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="card">
                <div class="card-header"><h4><b><center>Registro de solicitudes confirmadas</center></b></h4></div>
                    <div class="card-body">
                        <div class="alert alert-info" role="alert">
                            <center>¡Lista de solicitudes ordenada de forma <i>ascendente, según fecha de regristro</i> en el sistema!</center>
                        </div>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <ul class="list-group">
                            <table class="table">
                            <thead class="thead-dark">
                                    <tr>
                                        <th scope="col"><center>Factura#</center></th>
                                        <th scope="col"><center>Nombre del cliente</center></th>
                                        <th scope="col"><center>Domicilio</center></th>
                                        <th scope="col"><center>Teléfono</center></th>
                                        <th scope="col"><center>Análisis Solicitados</center></th>
                                        <th scope="col"><center>Costo del Servicio</center></th>
                                        <th scope="col"><center></center></th>
                                    </tr>
                                </thead>
                               <tbody>
                                    <?php $__currentLoopData = $confirmadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><center><?php echo e($solicitud->idFactura); ?></center></th>
                                            <th scope="row"><center><?php echo e($solicitud->nombreDelCiente); ?></center></th>
                                            <th scope="row"><center><?php echo e($solicitud->domicilioDelCiente); ?></center></th>
                                            <th scope="row"><center><?php echo e($solicitud->telefonoDelCliente); ?></center></th>
                                            <th scope="row"><center><?php echo e($solicitud->analisisSolicitados); ?></center></th>
                                            <th scope="row"><center><?php echo e($solicitud->costoDelServicio); ?></center></th>
                                            <td scope="row"><center><a href="/solicitudesConfirmadas/cambioDeEstado/<?php echo e($solicitud->idDeSolicitud); ?>" class="btn btn-primary">Procesar Solicitud</a> </center></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <center><a href="/homeAdmins" class="btn btn-danger">Ir al menú principal</a></center>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/solicitudes/confirmadas.blade.php ENDPATH**/ ?>