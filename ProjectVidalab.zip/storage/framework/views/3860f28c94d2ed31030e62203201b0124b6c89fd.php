<!html Doctype>
<html>
  <head>
  </head>
  <body>
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
                <button id="navbarDropdown" class="btn btn-primary dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e('Enviar una notificacion'); ?>

                </button>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <li role="presentation"><a class="dropdown-item" href="/notificacionEspecifica">
                      <strong><?php echo e(__('Notificación específica')); ?></strong>
                  </a></li>
                  <li role="presentation" class="divider"></li>
                    <a class='dropdown-item' href="notificacionMasiva">
                                      <strong>  <?php echo e('Notificación masiva'); ?></strong>
                    </a>
                </div>

  </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  </body>
</html>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/Notificaciones/Notificaciones.blade.php ENDPATH**/ ?>