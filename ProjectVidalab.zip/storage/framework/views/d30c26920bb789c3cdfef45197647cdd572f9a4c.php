
este es el modulo de pruebas
<br>
se esta probando esto <?php echo e($prueba); ?>

<?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/pruebas.blade.php ENDPATH**/ ?>