<!Doctype html>
<html>
<head>
  
</head>
<body>
  <?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
    <div class="col-md-8">
    <div class="card">
      <div class="card-header">
      <strong>  <?php echo e('Formulario de envio de notificaciones a un cliente especifico'); ?> </strong>
      </div>
      <div class="card-body">
        <form action="notificacionEspecifica" method="post" enctype="multipart/form-data" target="_self">
            <?php echo csrf_field(); ?>
          <label for="asunto"><strong>Asunto:</strong></label><br>
          <input type="text" name="asunto" value="" class="form-control" required ><br>
        <label for=""><strong>Mensaje:</strong></label><br><textarea  rows="6" cols="40" name="mensaje" class="form-control" required></textarea><br>
          <input type="file" name="file" >
        
          <br>
          <br>
          <label>Selecionar cliente</label><br>
          <select class="form-control" name="clienteOpcion">
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cliente->correoDelCliente); ?>"><?php echo e($cliente->nombreDelCliente); ?></option>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <br>
          <button type="submit" class="btn btn-primary" > Enviar</button>
        </form>
      </div>
      </body>
    </div>
  </div>
  </div>
  </div>
  <?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/NotificacionEspecifica.blade.php ENDPATH**/ ?>