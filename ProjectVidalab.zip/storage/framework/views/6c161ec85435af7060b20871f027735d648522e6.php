<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <h3><strong>Laboratorio Vidalab comunica</strong></h3>
  </head>
  <body>

      <h5><strong>Asunto: </strong></h5><p><?php echo e($data['asunto']); ?></p>
      <h5><strong>Mensaje: </strong></h5><p><?php echo e($data['mensaje']); ?></p>

  </body>
</html>
<?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/Notificaciones/Notificacion.blade.php ENDPATH**/ ?>