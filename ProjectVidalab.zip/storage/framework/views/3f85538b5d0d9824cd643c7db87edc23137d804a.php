

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3><b><center>Consultar Paquete registrado</center></b></h3>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col">
                    <label for="exampleFormControlSelect1">Código</label>
                    <input type="text" class="form-control" readonly="codigoDelPaquete" value="<?php echo e($paquete->codigoDelPaquete); ?>"/> <br>
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Nombre</label>
                    <input type="text" class="form-control" readonly="nombreDelPaquete" value="<?php echo e($paquete->nombreDelPaquete); ?>"/> <br>
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Costo</label>
                    <input type="text" class="form-control" readonly="costoDelPaquete" value="<?php echo e($paquete->costoDelPaquete); ?>"/> <br>
                </div>
            </div>

            <label for="exampleFormControlSelect1">Descripción</label>
            <textarea class="form-control" cols="30" rows="5" readonly="descripcionDelPaquete"><?php echo e($paquete->descripcionDelPaquete); ?></textarea> <br>

            <div class="row">
                <div class="col">
                    <center><a href="/paquetes" class="btn btn-danger">Regresar a la lista</a></center>
                </div>
                <div class="col">
                    <center><a href="/homeAdmins" class="btn btn-danger">Ir al menú principal</a></center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/paquetes/mostrar.blade.php ENDPATH**/ ?>