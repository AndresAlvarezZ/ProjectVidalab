

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-40">
            <div class="card">
                <div class="card-header"><h4><b><center>Registro de Administradores Activos</center></b></h4></div>
                    <div class="card-body"> 
                        <ul class="list-group">
                            <table class="table">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col"><center>Nombre</center></th>
                                        <th scope="col"><center>Identificación </center></th>
                                        <th scope="col"><center>Rol</center></th>
                                        <th scope="col"><center>Acción a realizar<center></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $administradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $administrador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><center><?php echo e($administrador->primerApellidoAdministrador); ?> <?php echo e($administrador->segundoApellidoAdministrador); ?> <?php echo e($administrador->nombreDelUsuarioAdministrador); ?></center></th>
                                        <td><center><?php echo e($administrador->dniDelUsuarioAdministrador); ?></center></td>
                                        <td><center>
                                            <?php if($administrador->rol == true): ?>
                                                Super Administrador
                                            <?php else: ?>
                                                Administrador
                                            <?php endif; ?>
                                            </center></td>
                                        <td><center><a href="/administradores/<?php echo e($administrador->id); ?>/editarEstado" class="btn btn-danger">Desactivar</a></center>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>                         
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <center><a href="/nuevoAdministrador" class="btn btn-dark">Registrar administrador</a>    |   <a href="/administradores/activos" class="btn btn-dark">Administradores Activos</a>    |   <a href="/administradores/inactivos" class="btn btn-dark">Administradores Inactivos</a>    |   <a href="/homeAdmins" class="btn btn-dark">Ir al menú principal</a></center>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/administrador/listarActivos.blade.php ENDPATH**/ ?>