

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="card">
        <div class="card-header">
            <h3><b><center>Procesar Solicitud</center></b></h3>
        </div>

        <div class="card-body">

            <form action="/solicitudesConfirmadas/procesarCambio/<?php echo e($solicitud->idDeSolicitud); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="row ">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Factura#</label>
                        <input type="number" class="form-control" readonly name="idFactura" value="<?php echo e($solicitud->idFactura); ?>" /> <br>
                        <?php $__errorArgs = ['idFactura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Nombre del cliente</label>
                        <input type="text" class="form-control" readonly name="nombreDelCiente" value="<?php echo e($solicitud->nombreDelCiente); ?>"/> <br>
                        <?php $__errorArgs = ['nombreDelCiente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Domicilio del cliente</label>
                        <input type="text" class="form-control" readonly name="domicilioDelCiente" value="<?php echo e($solicitud->domicilioDelCiente); ?>"/> <br>
                        <?php $__errorArgs = ['domicilioDelCiente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                    <div class="row ">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Teléfono del cliente</label>
                        <input type="text" class="form-control" readonly name="telefonoDelCliente" value="<?php echo e($solicitud->telefonoDelCliente); ?>"/> <br>
                        <?php $__errorArgs = ['telefonoDelCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Análisis Solicitados</label>
                        <input type="text" class="form-control" readonly name="analisisSolicitados" value="<?php echo e($solicitud->analisisSolicitados); ?>"/> <br>
                        <?php $__errorArgs = ['analisisSolicitados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Costo del servicio</label>
                        <input type="number" class="form-control" readonly name="costoDelServicio" value="<?php echo e($solicitud->costoDelServicio); ?>"/> <br>
                        <?php $__errorArgs = ['costoDelServicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                    <div class="col">
                        <label>Cambiar estado</label>
                       <br>
                       <select class="form-control" type="text" name="estado">
                           <option value="Finalizada">Finalizada</option>
                           <option value="Cancelada">Cancelada</option>
                       </select>
                        <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <br>
                <div class="row">
                    <div class="col">
                        <center><button type="submit" class="btn btn-success">Procesar solicitud</button></center>
                    </div>
                    <div class="col">
                        <center><a href="javascript: history.go(-1)" class="btn btn-primary">Cancelar y Volver</a></center>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/solicitudes/cambioDeEstadoConfirmadas.blade.php ENDPATH**/ ?>