

<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="card">
        <div class="card-header">
            <h3><b><center>Procesar Compra</center></b></h3>
        </div>

        <div class="card-body">

            <form action="/procesarFactura/<?php echo e($factura->idFactura); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Fecha</label>
                        <input type="text" class="form-control" readonly name="fecha" value="<?php echo e($factura->fecha); ?>" /> <br>
                        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Cédula del cliente</label>
                        <input type="text" class="form-control" readonly name="idCliente" value="<?php echo e($factura->idCliente); ?>"/> <br>
                        <?php $__errorArgs = ['idCliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Condición de compra</label>
                       <br>
                       <select class="form-control" type="text" name="condicionDeCompra">
                         <?php if ($factura->condicionDeCompra=='Cancelado'): ?>
                           <option value="Cancelado">Cancelado</option>
                           <option value="Pendiente">Pendiente</option>
                         <?php endif; ?>
                         <?php if ($factura->condicionDeCompra=='Pendiente'): ?>
                           <option value="Pendiente">Pendiente</option>
                           <option value="Cancelado">Cancelado</option>
                         <?php endif; ?>
                       </select>

                        <?php $__errorArgs = ['condicionDeCompra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Subtotal</label>
                        <input type="text" class="form-control" readonly name="total" value="<?php echo e($factura->total); ?>"/> <br>
                        <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Descuento</label>
                        <input type="text" class="form-control" readonly name="descuento" value="<?php echo e($factura->descuento); ?>"/> <br>
                        <?php $__errorArgs = ['descuento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Total</label>
                        <?php $total = $factura->total-$factura->descuento ?>
                        <input type="text" class="form-control" readonly name="subtotal" value="<?php echo e($total); ?>"/> <br>
                        <?php $__errorArgs = ['subtotal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col">
                        <center><button type="submit" class="btn btn-success">Procesar compra</button></center>
                    </div>
                    <div class="col">
                        <center><a href="javascript: history.go(-1)" class="btn btn-primary">Cancelar y Volver</a></center>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/facturas/actualizarFactura.blade.php ENDPATH**/ ?>