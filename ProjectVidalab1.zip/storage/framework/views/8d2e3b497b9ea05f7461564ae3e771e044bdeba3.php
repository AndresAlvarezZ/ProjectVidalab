

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3><b><center>Consultar Analisis registrado</center></b></h3>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col">
                    <label for="exampleFormControlSelect1">Código</label>
                    <input type="text" class="form-control" readonly="codigoDelAnalisis" value="<?php echo e($prueba->codigoDelAnalisis); ?>"/> <br>
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Nombre</label>
                    <input type="text" class="form-control" readonly="nombreDelAnalisis" value="<?php echo e($prueba->nombreDelAnalisis); ?>"/> <br>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label for="exampleFormControlSelect1">Costo</label>
                    <input type="text" class="form-control" readonly="costoDelAnalisis" value="<?php echo e($prueba->costoDelAnalisis); ?>"/> <br>
                </div>
                <div class="col">
                    <label for="exampleFormControlSelect1">Numero de máquina</label>
                    <input type="text" class="form-control" readonly="numeroDeMaquina" value="<?php echo e($prueba->numeroDeMaquina); ?>"/> <br>
                </div>
            </div>

            <label for="exampleFormControlSelect1">Descripción</label>
            <textarea class="form-control" cols="30" rows="5" readonly="descripcionDelAnalisis"><?php echo e($prueba->descripcionDelAnalisis); ?></textarea> <br>

            <div class="row">
                <div class="col">
                    <center><a href="/pruebas" class="btn btn-danger">Regresar a la lista</a></center>
                </div>
                <div class="col">
                    <center><a href="/homeAdmins" class="btn btn-danger">Ir al menú principal</a></center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/pruebas/mostrar.blade.php ENDPATH**/ ?>