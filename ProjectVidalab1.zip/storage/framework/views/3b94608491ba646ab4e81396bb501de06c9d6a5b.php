<!html Doctype>
<html>
  <head>
  </head>
  <body>
    
    <?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e('Enviar una notificacion'); ?>

                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="/notificacionEspecifica">
                        <strong><?php echo e(__('Notificación específica')); ?></strong>
                    </a>
                    <a class='dropdown-item' href="notificacionMasiva">
                                      <strong>  <?php echo e('Notificación masiva'); ?></strong>
                    </a>
                </div>

  </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>
  </body>
</html>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/Notificaciones.blade.php ENDPATH**/ ?>