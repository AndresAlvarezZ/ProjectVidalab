
	

<?php $__env->startSection('content'); ?>


	<div class="container">

        <div class="card-header">
           <h3><b><center>Catálogo de Análisis</center></b></h3>
        </div>
        <link rel="stylesheet" type="text/css" href="css/estiloDelCatalogo.css?v=<?php echo(rand()); ?>">
				<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		    <script src="<?php echo e(asset('js/localStorage.js')); ?>?v=<?php echo(rand()); ?>"defer></script>


        <?php $__currentLoopData = $pruebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prueba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <img src="imagenes/microbiologia2.jpg">
                <br>
                <h5><b><?php echo e($prueba->nombreDelAnalisis); ?></b></h5>
                <p>Costo: ₡ <?php echo e($prueba->costoDelAnalisis); ?></p>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($prueba->codigoDelAnalisis); ?>">Leer más</button>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="card-header">
           <h3><b><center>Catálogo de Ofertas de Paquetes de Análisis</center></b></h3>
        </div>
            <?php $__currentLoopData = $paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <img src="imagenes/microbiologia.jpg">
                    <br>
                    <h5><b><?php echo e($paquete->nombreDelPaquete); ?></b></h5>
                    <p>Costo: ₡ <?php echo e($paquete->costoDelPaquete); ?></p>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($paquete->codigoDelPaquete); ?>">Leer más</button>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pop_up.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.AppAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/catalogo/indexAdmins.blade.php ENDPATH**/ ?>