

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="es-ES">

<head>
    <title>Carrito de compras</title>
    <link href="<?php echo e(asset('css/estilo.css')); ?>?v=<?php echo(rand()); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/localStorage.js')); ?>?v=<?php echo(rand()); ?>"defer></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('js/sesion.js')); ?>?v=<?php echo(rand()); ?>"defer></script>

<body>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          <h1 class=>Carrito de Compras</h1>
        </div>
        <div class="card-body">
          <table id="tabla">
              <thead>

              </thead>
              <tbody>

              </tbody>
          </table>
        </div>
        <div class="card-foot">
          <div class="">
            <form class="" id="prueba" method="post">
            </form>
            <a href="/compras/FinalizarCompra" type="button" class="btn btn-primary">Procesar compra</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/Compras/carrito.blade.php ENDPATH**/ ?>