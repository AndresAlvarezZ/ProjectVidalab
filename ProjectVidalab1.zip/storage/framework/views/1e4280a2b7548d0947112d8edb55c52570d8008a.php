

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="card">
                <div class="card-header"><h4><b><center>Registro de Analisis</center></b></h4></div>
                    <div class="card-body">
                        <ul class="list-group">
                            <table class="table">
                            <thead class="thead-dark">
                                    <tr>
                                        <th scope="col"><center>Código</center></th>
                                        <th scope="col"><center>Nombre</center></th>
                                        <th scope="col"><center>Costo</center></th>
                                        <th scope="col"><center>Acción a realizar</center></th>
                                    </tr>
                                </thead>
                               <tbody>
                                    <?php $__currentLoopData = $pruebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prueba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><center><?php echo e($prueba->codigoDelAnalisis); ?></center></th>
                                            <th scope="row"><center><?php echo e($prueba->nombreDelAnalisis); ?></center></th>
                                            <td><center>₡ <?php echo e($prueba->costoDelAnalisis); ?></center></td>
                                            <td><center><a href="/pruebas/<?php echo e($prueba->codigoDelAnalisis); ?>" class="btn btn-primary">Consultar datos</a> |
                                            <a href="/pruebas/<?php echo e($prueba->codigoDelAnalisis); ?>/editar" class="btn btn-success">Editar datos</a> |
                                            <a href="/pruebas/<?php echo e($prueba->codigoDelAnalisis); ?>/eliminar" class="btn btn-danger">Eliminar datos</a> </center></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <center><a href="/pruebas/agregar" class="btn btn-dark">Registrar Análisis</a>    |   <a href="/paquetes" class="btn btn-dark">Desplegar paquetes de análisis</a>    |    <a href="/catalogos" class="btn btn-dark">Ir al catálogo</a>    |    <a href="/homeAdmins" class="btn btn-dark">Ir al menú principal</a></center>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/pruebas/index.blade.php ENDPATH**/ ?>