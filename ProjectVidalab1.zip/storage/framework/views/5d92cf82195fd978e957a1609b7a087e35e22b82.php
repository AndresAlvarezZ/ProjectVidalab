

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
           <h3><b><center>Registrar nuevo Paquete</center></b></h3>
        </div>

        <div class="card-body">
            <form action="/paquetes" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        <label for="exampleFormControlSelect1">Código</label>
                        <input type="text" class="form-control" placeholder="Escriba el código del paquete" name="codigoDelPaquete" value="<?php echo e(old('codigoDelPaquete')); ?>" /> <br>
                        <?php $__errorArgs = ['codigoDelPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Nombre</label>
                        <input type="text" class="form-control" placeholder="Escriba el nombre del paquete" name="nombreDelPaquete" value="<?php echo e(old('nombreDelPaquete')); ?>"/> <br>
                        <?php $__errorArgs = ['nombreDelPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col">
                        <label for="exampleFormControlSelect1">Costo</label>
                        <input type="text" class="form-control" placeholder="Escriba el costo del paquete" name="costoDelPaquete" value="<?php echo e(old('costoDelPaquete')); ?>"/> <br>
                        <?php $__errorArgs = ['costoDelPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>


                <label for="exampleFormControlSelect1">Descripción</label>
                <textarea name="descripcionDelPaquete" class="form-control" cols="30" rows="5" placeholder="Escriba la descripción del paquete"><?php echo e(old('descripcionDelPaquete')); ?></textarea> <br>
                <?php $__errorArgs = ['descripcionDelPaquete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="row">
                    <div class="col">
                        <center><button type="submit" class="btn btn-success">Registrar paquete</button></center>
                    </div>
                    <div class="col">
                        <center><a href="/paquetes" class="btn btn-danger">Cancelar y Volver</a></center>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ProjectVidalab\resources\views/paquetes/agregar.blade.php ENDPATH**/ ?>