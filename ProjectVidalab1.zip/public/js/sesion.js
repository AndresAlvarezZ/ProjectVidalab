
swal({
  title: 'Laboratorio vidalab recuerda',
  text: 'Debes iniciar sesion o registrarte para completar la compra',
  icon: 'warning',
});
